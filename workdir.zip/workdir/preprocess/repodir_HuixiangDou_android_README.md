# 茴香豆 Android 辅助

这是基于 [抢红包 app](https://github.com/xbdcc/GrabRedEnvelope) 软件的二次开发。

* 移除抢红包功能，重新用于 LLM RAG chat
* 它基于 android 系统 API 工作，原理上可以控制所有 UI（不只是即时通讯软件），风险自行承担 

# License

注意软件使用 [GPL 协议](LICENSE)。
