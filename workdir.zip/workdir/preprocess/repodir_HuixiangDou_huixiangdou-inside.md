# HuixiangDou Inside

| ID  | Environment                 | IM Application | Description                                                            | Screen Shortcut                                                  |
| --- | --------------------------- | -------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------- |
| 1   | openmmlab user group        | wechat         | reply user question                                                    | <img src="./resource/figures/inside-mmpose.jpg" width="300">     |
| 2   | ncnn contributor group      | wechat         | explain software and hardware terminologies and pretending to be human | <img src="./resource/figures/inside-ncnn-group.jpg" width="300"> |
| 3   | inner middleware user group | lark           | reply user question                                                    | <img src="./resource/figures/inside-middleware.png" width="300"> |
