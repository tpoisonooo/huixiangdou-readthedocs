---
name: 📝 others
about: discussion, suggestion and question
---

## detail | 详细描述 | 詳細な説明
