# **SFT tools have moved to [sft directory](../../sft/)**

# Devops tools

- dump_redis_query.py   # for web version, dump all question from redis to `query.jsonl`
- update_fs_max_len.py  #  for web version, update all users' max text length config of remote LLM
- get_puyu_model_list.py  # for inner API, get all puyu API model list
